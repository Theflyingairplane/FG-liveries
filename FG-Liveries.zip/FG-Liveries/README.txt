Ajel Dyre G. Ceballos, I love flying
BLK 10, L14, Tierra Hermose, Calamba Laguna
18/08/2022


Dear User,


	This is a Livery pack for the Flightgear flight simulator. I hope that you enjoy using it to fly around the world of Flightgear.
This ZIP file and all its documents, the second you download it, it is all yours, feel free to edit, delete, or change the liveries
in this zip file, it will be maintained free for you. I will update liveries then and now, I hope this finds you well, and thank you
for downloading it, I hope that this Zip file will remain through the years. If I can no longer edit it, I will let others takeover 
the job of updating this, thank you. You can feel free to edit, change, or delete any of the components in this ZIP file.


Best of wishes,
Ajel